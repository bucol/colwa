Halo.
handler.help = ['canvapro']
handler.tags = ['canvapro']
handler.command = /^canvapro/i
handler.register = true

module.exports = handler